# Functions:

- [`owner()`](#Ownable-owner--)

- [`isOwner()`](#Ownable-isOwner--)

- [`renounceOwnership()`](#Ownable-renounceOwnership--)

- [`transferOwnership(address newOwner)`](#Ownable-transferOwnership-address-)

# Events:

- [`TransferOwnership(address oldOwner, address newOwner)`](#Ownable-TransferOwnership-address-address-)

# Function `owner() → address` {#Ownable-owner--}

No description

# Function `isOwner() → bool` {#Ownable-isOwner--}

No description

# Function `renounceOwnership()` {#Ownable-renounceOwnership--}

No description

# Function `transferOwnership(address newOwner)` {#Ownable-transferOwnership-address-}

No description

# Event `TransferOwnership(address oldOwner, address newOwner)` {#Ownable-TransferOwnership-address-address-}

No description
