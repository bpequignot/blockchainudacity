# Functions:

- [`setCompleted(uint256 completed)`](#Migrations-setCompleted-uint256-)

- [`upgrade(address new_address)`](#Migrations-upgrade-address-)

# Function `setCompleted(uint256 completed)` {#Migrations-setCompleted-uint256-}

No description

# Function `upgrade(address new_address)` {#Migrations-upgrade-address-}

No description
