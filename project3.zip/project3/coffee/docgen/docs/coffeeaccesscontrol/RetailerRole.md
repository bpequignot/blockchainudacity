# Functions:

- [`isRetailer(address account)`](#RetailerRole-isRetailer-address-)

- [`addRetailer(address account)`](#RetailerRole-addRetailer-address-)

- [`renounceRetailer()`](#RetailerRole-renounceRetailer--)

# Function `isRetailer(address account) → bool` {#RetailerRole-isRetailer-address-}

No description

# Function `addRetailer(address account)` {#RetailerRole-addRetailer-address-}

No description

# Function `renounceRetailer()` {#RetailerRole-renounceRetailer--}

No description
