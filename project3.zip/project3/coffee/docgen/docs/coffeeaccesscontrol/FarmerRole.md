# Functions:

- [`isFarmer(address account)`](#FarmerRole-isFarmer-address-)

- [`addFarmer(address account)`](#FarmerRole-addFarmer-address-)

- [`renounceFarmer()`](#FarmerRole-renounceFarmer--)

# Events:

- [`FarmerAdded(address account)`](#FarmerRole-FarmerAdded-address-)

- [`FarmerRemoved(address account)`](#FarmerRole-FarmerRemoved-address-)

# Function `isFarmer(address account) → bool` {#FarmerRole-isFarmer-address-}

No description

# Function `addFarmer(address account)` {#FarmerRole-addFarmer-address-}

No description

# Function `renounceFarmer()` {#FarmerRole-renounceFarmer--}

No description

# Event `FarmerAdded(address account)` {#FarmerRole-FarmerAdded-address-}

No description

# Event `FarmerRemoved(address account)` {#FarmerRole-FarmerRemoved-address-}

No description
