# Functions:

- [`isConsumer(address account)`](#ConsumerRole-isConsumer-address-)

- [`addConsumer(address account)`](#ConsumerRole-addConsumer-address-)

- [`renounceConsumer()`](#ConsumerRole-renounceConsumer--)

# Function `isConsumer(address account) → bool` {#ConsumerRole-isConsumer-address-}

No description

# Function `addConsumer(address account)` {#ConsumerRole-addConsumer-address-}

No description

# Function `renounceConsumer()` {#ConsumerRole-renounceConsumer--}

No description
