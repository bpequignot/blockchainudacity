Library for managing addresses assigned to a Role.

# Functions:
