# Functions:

- [`isDistributor(address account)`](#DistributorRole-isDistributor-address-)

- [`addDistributor(address account)`](#DistributorRole-addDistributor-address-)

- [`renounceDistributor()`](#DistributorRole-renounceDistributor--)

# Function `isDistributor(address account) → bool` {#DistributorRole-isDistributor-address-}

No description

# Function `addDistributor(address account)` {#DistributorRole-addDistributor-address-}

No description

# Function `renounceDistributor()` {#DistributorRole-renounceDistributor--}

No description
